export const urls = {
    home: '/',
    filters: '/filters',
    files: '/files'
};
