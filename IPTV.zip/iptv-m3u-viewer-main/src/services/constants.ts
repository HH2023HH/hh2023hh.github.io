export const STORAGE_KEY = {
    FILES: 'files',
    FILTERS: 'filters',
}